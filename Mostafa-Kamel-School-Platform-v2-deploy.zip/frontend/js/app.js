const token = localStorage.getItem("mk_token");
const user = JSON.parse(localStorage.getItem("mk_user") || "null");

if (!token || !user) {
  location.href = "/login.html";
}

const api = async (url, options = {}) => {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
      ...(options.headers || {})
    }
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "حدث خطأ");
  return data;
};


function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch]));
}

document.getElementById("welcomeName").textContent = `مرحبًا ${user.name} 👋`;
document.getElementById("roleText").textContent =
  ({admin:"مدير النظام",teacher:"مدرس",student:"طالب",parent:"ولي أمر"})[user.role] || user.role;

document.querySelectorAll("[data-section]").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
    document.getElementById(btn.dataset.section).classList.add("active");
  });
});

function logout() {
  localStorage.removeItem("mk_token");
  localStorage.removeItem("mk_user");
  location.href = "/login.html";
}

document.getElementById("logout").onclick = logout;
document.getElementById("mobileLogout").onclick = logout;

async function loadHome() {
  const data = await api("/api/school/overview");
  document.getElementById("stats").innerHTML = `
    <div class="stat">👨‍🎓 الطلاب<b>${data.counts.students}</b></div>
    <div class="stat">👨‍🏫 المدرسون<b>${data.counts.teachers}</b></div>
    <div class="stat">📚 المواد<b>${data.counts.subjects}</b></div>
    <div class="stat">📝 الواجبات<b>${data.counts.assignments}</b></div>
  `;

  document.getElementById("announcements").innerHTML =
    data.announcements.map(a => `
      <div class="announcement">
        <b>${escapeHTML(a.title)}</b>
        <div class="muted">${escapeHTML(a.body)}</div>
      </div>
    `).join("") || "<p>لا توجد إعلانات.</p>";
}

async function loadLessons() {
  const data = await api("/api/school/lessons");
  document.getElementById("lessonsList").innerHTML =
    data.lessons.map(l => `
      <article class="card">
        <span class="badge">${escapeHTML(l.subject_name)}</span>
        <h3>${escapeHTML(l.title)}</h3>
        <p>${escapeHTML(l.description || "")}</p>
        <p class="muted">${escapeHTML(l.content || "")}</p>
      </article>
    `).join("") || "<p>لا توجد دروس.</p>";
}

async function loadAssignments() {
  const data = await api("/api/school/assignments");
  document.getElementById("assignmentsList").innerHTML =
    data.assignments.map(a => `
      <article class="card">
        <span class="badge">${escapeHTML(a.subject_name)}</span>
        <h3>${escapeHTML(a.title)}</h3>
        <p>${escapeHTML(a.description || "")}</p>
        <p>📅 التسليم: ${escapeHTML(a.due_date || "غير محدد")}</p>
        <p>الدرجة: ${a.max_grade}</p>
        ${user.role === "student" ? `
          <button class="btn primary" onclick="submitAssignment(${a.id})">
            تسليم الواجب
          </button>` : ""}
      </article>
    `).join("") || "<p>لا توجد واجبات.</p>";
}

async function submitAssignment(id) {
  const answer = prompt("اكتب إجابتك:");
  if (!answer) return;

  await api("/api/school/submissions", {
    method: "POST",
    body: JSON.stringify({assignment_id:id, answer})
  });

  alert("تم تسليم الواجب.");
}

async function loadGrades() {
  const data = await api("/api/school/grades");
  document.getElementById("gradesList").innerHTML =
    data.grades.map(g => `
      <article class="card">
        <span class="badge">${escapeHTML(g.subject_name)}</span>
        <h3>${escapeHTML(g.title)}</h3>
        <strong>${Number(g.grade)} / ${Number(g.max_grade)}</strong>
      </article>
    `).join("") || "<p>لا توجد درجات.</p>";
}

document.getElementById("aiForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const input = document.getElementById("question");
  const chat = document.getElementById("chat");
  const q = input.value.trim();
  if (!q) return;

  chat.innerHTML += `<div class="msg user-msg">${escapeHTML(q)}</div>`;
  input.value = "";

  try {
    const data = await api("/api/ai/chat", {
      method: "POST",
      body: JSON.stringify({question:q})
    });
    chat.innerHTML += `<div class="msg ai-msg">${escapeHTML(data.answer).replace(/\n/g, "<br>")}</div>`;
    chat.scrollTop = chat.scrollHeight;
  } catch (err) {
    chat.innerHTML += `<div class="msg ai-msg">${escapeHTML(err.message)}</div>`;
  }
});

Promise.all([loadHome(), loadLessons(), loadAssignments(), loadGrades()])
  .catch(err => console.error(err));
