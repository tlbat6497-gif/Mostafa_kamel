const path = require("path");
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const dotenv = require("dotenv");
const { initDatabase } = require("./database");
const authRoutes = require("./routes/auth");
const schoolRoutes = require("./routes/school");
const aiRoutes = require("./routes/ai");
const adminRoutes = require("./routes/admin");
const registrationRoutes = require("./routes/registration");

dotenv.config();

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error("JWT_SECRET is required and must be at least 32 characters long.");
}

const app = express();
const PORT = process.env.PORT || 3000;
initDatabase();

const allowedOrigins = (process.env.CORS_ORIGIN || "").split(",").map(s => s.trim()).filter(Boolean);
if (allowedOrigins.length) {
  app.use(cors({ origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("CORS origin not allowed"));
  }}));
}
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { message: "محاولات تسجيل الدخول كثيرة. حاول مرة أخرى بعد قليل." } });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false, message: { message: "طلبات AI كثيرة جدًا. حاول بعد دقيقة." } });

app.use("/api/auth/login", loginLimiter);
app.use("/api/ai/chat", aiLimiter);
app.use("/api/auth", authRoutes);
app.use("/api/school", schoolRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/register", registrationRoutes);
app.use(express.static(path.join(__dirname, "..", "frontend")));

app.get("/api/health", (req, res) => res.json({ success: true, school: "Mostafa Kamel School", status: "online" }));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "..", "frontend", "index.html")));

app.listen(PORT, () => console.log(`Mostafa Kamel School Platform running on http://localhost:${PORT}`));
