const OpenAI = require("openai");

const SYSTEM_PROMPT = `أنت MK AI، المساعد التعليمي لمنصة مدرسة مصطفى كامل بحلوان.
دورك مساعدة الطالب على الفهم وليس الغش. اشرح بالعربية الواضحة، ويمكن استخدام المصطلحات الإنجليزية عند الحاجة.
في وضع المذاكرة: لا تعطِ الإجابة النهائية مباشرة إذا كان السؤال واجبًا؛ ابدأ بتلميح ثم خطوات.
إذا طلب الطالب شرح مفهوم، اشرحه مع مثال تدريجي. لا تدّعِ أنك تعرف محتوى المدرسة الداخلي إلا إذا أُعطي لك.`;

async function askOpenAI(question, user) {
  if (!process.env.OPENAI_API_KEY) return null;
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    instructions: `${SYSTEM_PROMPT}\nاسم المستخدم: ${user.name}. دوره: ${user.role}.`,
    input: question,
    max_output_tokens: 700
  });
  return response.output_text || null;
}

async function askGemini(question, user) {
  if (!process.env.GEMINI_API_KEY) return null;
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
  const prompt = `${SYSTEM_PROMPT}\nاسم المستخدم: ${user.name}. دوره: ${user.role}.\n\nسؤال الطالب:\n${question}`;
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { maxOutputTokens: 700, temperature: 0.4 } })
  });
  if (!response.ok) throw new Error(`Gemini HTTP ${response.status}`);
  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || null;
}

// No-key fallback: deterministic educational helper so the platform still works offline.
function askLocalAI(question) {
  const q = String(question || "").trim();
  const lower = q.toLowerCase();
  if (!q) return "اكتب سؤالك وسأساعدك.";

  if (/^(سلام|اهلا|أهلا|hello|hi)/i.test(q)) {
    return "أهلًا 👋 أنا MK AI. اكتب الدرس أو السؤال الذي تريد فهمه، وسنحله خطوة بخطوة.";
  }
  if (lower.includes("معادلة") || lower.includes("equation")) {
    return "خلينا نبدأ بطريقة بسيطة: في المعادلة، هدفنا نعزل المتغير.\n1) اجمع أو اطرح نفس القيمة من الطرفين.\n2) اقسم الطرفين على معامل المتغير.\n3) عوّض بالنتيجة للتأكد.\nابعتلي المعادلة نفسها وسأمشي معك خطوة خطوة.";
  }
  if (lower.includes("نيوتن") || lower.includes("قانون نيوتن")) {
    return "قانون نيوتن الثاني: F = m × a.\nالقوة تساوي الكتلة مضروبة في العجلة.\nلو أعطيتني قيم m و a أساعدك في ترتيب الحل، بدون قفز للنتيجة مباشرة.";
  }
  if (lower.includes("مشتقة") || lower.includes("derivative")) {
    return "في المشتقات، ابدأ بقاعدة القوة: مشتقة x^n هي n×x^(n-1).\nاكتب الدالة التي تريد اشتقاقها وسأشرحها خطوة بخطوة.";
  }
  if (lower.includes("ترجمة") || lower.includes("translate")) {
    return "ابعت الجملة التي تريد ترجمتها وحدد الاتجاه: عربي → إنجليزي أو إنجليزي → عربي.";
  }
  return `أقدر أساعدك في المذاكرة خطوة بخطوة.\nسؤالك: ${q}\n\nحاليًا MK AI يعمل في الوضع المحلي بدون مفتاح API. للحصول على إجابات توليدية أعمق، يمكن تفعيل Gemini المجاني من إعدادات السيرفر.`;
}

async function askMKAI({ question, user }) {
  if (process.env.OPENAI_API_KEY) {
    try {
      const answer = await askOpenAI(question, user);
      if (answer) return { answer, live: true, provider: "openai" };
    } catch (error) { console.error("OpenAI unavailable:", error?.message || error); }
  }

  if (process.env.GEMINI_API_KEY) {
    try {
      const answer = await askGemini(question, user);
      if (answer) return { answer, live: true, provider: "gemini" };
    } catch (error) { console.error("Gemini unavailable:", error?.message || error); }
  }

  return { answer: askLocalAI(question), live: false, provider: "local" };
}

function getAIStatus() {
  return {
    enabled: true,
    providers: {
      openai: Boolean(process.env.OPENAI_API_KEY),
      gemini: Boolean(process.env.GEMINI_API_KEY),
      local: true
    },
    model: process.env.OPENAI_API_KEY
      ? (process.env.OPENAI_MODEL || "gpt-5.6-luna")
      : process.env.GEMINI_API_KEY
        ? (process.env.GEMINI_MODEL || "gemini-2.5-flash-lite")
        : "local-educational"
  };
}

module.exports = { askMKAI, getAIStatus };
