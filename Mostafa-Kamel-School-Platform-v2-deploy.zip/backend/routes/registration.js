const router = require("express").Router();
const bcrypt = require("bcryptjs");
const { db } = require("../database");

const validEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

router.post("/students", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2) return res.status(400).json({ message: "اكتب اسمًا صحيحًا." });
  if (!validEmail(email)) return res.status(400).json({ message: "البريد الإلكتروني غير صحيح." });
  if (password.length < 8) return res.status(400).json({ message: "كلمة المرور يجب أن تكون 8 أحرف على الأقل." });

  if (db.prepare("SELECT id FROM users WHERE lower(email)=?").get(email)) {
    return res.status(409).json({ message: "البريد الإلكتروني مستخدم بالفعل." });
  }

  const result = db.prepare(
    "INSERT INTO users(name,email,password,role) VALUES(?,?,?,'student')"
  ).run(name, email, bcrypt.hashSync(password, 10));

  res.status(201).json({ message: "تم إنشاء حساب الطالب بنجاح.", id: result.lastInsertRowid });
});

module.exports = router;
