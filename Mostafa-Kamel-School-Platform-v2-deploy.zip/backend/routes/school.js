const router = require("express").Router();
const { db } = require("../database");
const { auth, roles } = require("../middleware/auth");

function getOwnedSubject(subjectId, userId) {
  return db.prepare("SELECT id FROM subjects WHERE id=? AND teacher_id=?").get(subjectId, userId);
}

router.get("/overview", auth, (req, res) => {
  const counts = {
    students: db.prepare("SELECT COUNT(*) count FROM users WHERE role='student'").get().count,
    teachers: db.prepare("SELECT COUNT(*) count FROM users WHERE role='teacher'").get().count,
    subjects: db.prepare("SELECT COUNT(*) count FROM subjects").get().count,
    assignments: db.prepare("SELECT COUNT(*) count FROM assignments").get().count
  };
  const announcements = db.prepare("SELECT id,title,body,created_at FROM announcements ORDER BY id DESC LIMIT 10").all();
  res.json({ counts, announcements });
});

router.get("/subjects", auth, (req, res) => {
  res.json({ subjects: db.prepare(`
    SELECT subjects.*, users.name AS teacher_name
    FROM subjects LEFT JOIN users ON users.id=subjects.teacher_id ORDER BY subjects.id DESC
  `).all() });
});

router.get("/lessons", auth, (req, res) => {
  res.json({ lessons: db.prepare(`
    SELECT lessons.*, subjects.name AS subject_name
    FROM lessons JOIN subjects ON subjects.id=lessons.subject_id ORDER BY lessons.id DESC
  `).all() });
});

router.get("/assignments", auth, (req, res) => {
  res.json({ assignments: db.prepare(`
    SELECT assignments.*, subjects.name AS subject_name
    FROM assignments JOIN subjects ON subjects.id=assignments.subject_id ORDER BY assignments.id DESC
  `).all() });
});

router.post("/lessons", auth, roles("admin", "teacher"), (req, res) => {
  const subjectId = Number(req.body.subject_id);
  const title = String(req.body.title || "").trim();
  if (!Number.isInteger(subjectId) || subjectId <= 0 || !title) return res.status(400).json({ message: "المادة والعنوان مطلوبان." });
  if (req.user.role === "teacher" && !getOwnedSubject(subjectId, req.user.id)) return res.status(403).json({ message: "لا يمكنك إضافة درس لمادة ليست من موادك." });

  const result = db.prepare(`INSERT INTO lessons(subject_id,title,description,content,created_by) VALUES(?,?,?,?,?)`).run(
    subjectId, title, String(req.body.description || ""), String(req.body.content || ""), req.user.id
  );
  res.status(201).json({ id: result.lastInsertRowid });
});

router.post("/assignments", auth, roles("admin", "teacher"), (req, res) => {
  const subjectId = Number(req.body.subject_id);
  const title = String(req.body.title || "").trim();
  const maxGrade = Number(req.body.max_grade ?? 100);
  if (!Number.isInteger(subjectId) || subjectId <= 0 || !title) return res.status(400).json({ message: "المادة والعنوان مطلوبان." });
  if (!Number.isFinite(maxGrade) || maxGrade <= 0 || maxGrade > 1000) return res.status(400).json({ message: "الدرجة القصوى غير صحيحة." });
  if (req.user.role === "teacher" && !getOwnedSubject(subjectId, req.user.id)) return res.status(403).json({ message: "لا يمكنك إنشاء واجب لمادة ليست من موادك." });

  const result = db.prepare(`INSERT INTO assignments(subject_id,title,description,due_date,max_grade,created_by) VALUES(?,?,?,?,?,?)`).run(
    subjectId, title, String(req.body.description || ""), String(req.body.due_date || ""), maxGrade, req.user.id
  );
  res.status(201).json({ id: result.lastInsertRowid });
});

router.post("/submissions", auth, roles("student"), (req, res) => {
  const assignmentId = Number(req.body.assignment_id);
  const answer = String(req.body.answer || "").trim();
  if (!Number.isInteger(assignmentId) || assignmentId <= 0 || !answer) return res.status(400).json({ message: "الواجب والإجابة مطلوبان." });

  const assignment = db.prepare("SELECT id,due_date FROM assignments WHERE id=?").get(assignmentId);
  if (!assignment) return res.status(404).json({ message: "الواجب غير موجود." });
  if (assignment.due_date && !Number.isNaN(Date.parse(assignment.due_date)) && Date.now() > Date.parse(`${assignment.due_date}T23:59:59`)) {
    return res.status(400).json({ message: "انتهى موعد تسليم الواجب." });
  }

  db.prepare(`INSERT INTO submissions(assignment_id,student_id,answer) VALUES(?,?,?)
    ON CONFLICT(assignment_id,student_id) DO UPDATE SET answer=excluded.answer, submitted_at=CURRENT_TIMESTAMP`)
    .run(assignmentId, req.user.id, answer);
  res.json({ message: "تم تسليم الواجب." });
});

router.get("/grades", auth, (req, res) => {
  if (req.user.role === "student") {
    return res.json({ grades: db.prepare(`SELECT grades.*, subjects.name AS subject_name FROM grades JOIN subjects ON subjects.id=grades.subject_id WHERE student_id=? ORDER BY grades.id DESC`).all(req.user.id) });
  }
  if (req.user.role === "parent") {
    return res.json({ grades: db.prepare(`SELECT grades.*, subjects.name AS subject_name, users.name AS student_name FROM grades JOIN subjects ON subjects.id=grades.subject_id JOIN users ON users.id=grades.student_id JOIN parent_students ps ON ps.student_id=grades.student_id WHERE ps.parent_id=? ORDER BY grades.id DESC`).all(req.user.id) });
  }
  if (req.user.role === "teacher") {
    return res.json({ grades: db.prepare(`SELECT grades.*, subjects.name AS subject_name, users.name AS student_name FROM grades JOIN subjects ON subjects.id=grades.subject_id JOIN users ON users.id=grades.student_id WHERE subjects.teacher_id=? ORDER BY grades.id DESC`).all(req.user.id) });
  }
  return res.json({ grades: db.prepare(`SELECT grades.*, subjects.name AS subject_name, users.name AS student_name FROM grades JOIN subjects ON subjects.id=grades.subject_id JOIN users ON users.id=grades.student_id ORDER BY grades.id DESC`).all() });
});

router.get("/attendance", auth, (req, res) => {
  if (req.user.role === "student") return res.json({ attendance: db.prepare("SELECT * FROM attendance WHERE student_id=? ORDER BY date DESC").all(req.user.id) });
  if (req.user.role === "parent") return res.json({ attendance: db.prepare(`SELECT attendance.*, users.name AS student_name FROM attendance JOIN users ON users.id=attendance.student_id JOIN parent_students ps ON ps.student_id=attendance.student_id WHERE ps.parent_id=? ORDER BY date DESC`).all(req.user.id) });
  if (req.user.role === "teacher") return res.json({ attendance: db.prepare(`SELECT attendance.*, users.name AS student_name FROM attendance JOIN users ON users.id=attendance.student_id WHERE EXISTS (SELECT 1 FROM grades g JOIN subjects s ON s.id=g.subject_id WHERE g.student_id=attendance.student_id AND s.teacher_id=?) ORDER BY date DESC`).all(req.user.id) });
  return res.json({ attendance: db.prepare(`SELECT attendance.*, users.name AS student_name FROM attendance JOIN users ON users.id=attendance.student_id ORDER BY date DESC`).all() });
});

module.exports = router;
