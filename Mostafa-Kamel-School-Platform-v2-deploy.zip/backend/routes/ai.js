const router = require("express").Router();
const { auth } = require("../middleware/auth");
const { askMKAI, getAIStatus } = require("../services/aiService");

router.post("/chat", auth, async (req, res) => {
  const question = String(req.body.question || "").trim();
  if (!question) return res.status(400).json({ message: "اكتب سؤالك أولًا." });
  if (question.length > 4000) return res.status(400).json({ message: "السؤال طويل جدًا." });

  try {
    res.json(await askMKAI({ question, user: req.user }));
  } catch (error) {
    console.error("MK AI error:", error?.message || error);
    res.status(502).json({ message: "لم يتمكن أي مزود AI من الرد حاليًا. راجع مفاتيح API والإعدادات." });
  }
});

router.get("/status", auth, (req, res) => res.json(getAIStatus()));
module.exports = router;
