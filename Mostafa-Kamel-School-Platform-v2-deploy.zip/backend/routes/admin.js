const router = require("express").Router();
const bcrypt = require("bcryptjs");
const { db } = require("../database");
const { auth, roles } = require("../middleware/auth");

const validEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

router.use(auth, roles("admin"));

router.get("/teachers", (req, res) => {
  const teachers = db.prepare(`
    SELECT id,name,email,created_at
    FROM users WHERE role='teacher' ORDER BY id DESC
  `).all();
  res.json({ teachers });
});

router.post("/teachers", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2) return res.status(400).json({ message: "اسم المدرس غير صحيح." });
  if (!validEmail(email)) return res.status(400).json({ message: "البريد الإلكتروني غير صحيح." });
  if (password.length < 8) return res.status(400).json({ message: "كلمة المرور يجب أن تكون 8 أحرف على الأقل." });

  const exists = db.prepare("SELECT id FROM users WHERE lower(email)=?").get(email);
  if (exists) return res.status(409).json({ message: "البريد الإلكتروني مستخدم بالفعل." });

  const result = db.prepare(
    "INSERT INTO users(name,email,password,role) VALUES(?,?,?,'teacher')"
  ).run(name, email, bcrypt.hashSync(password, 10));

  res.status(201).json({
    message: "تم إنشاء حساب المدرس.",
    teacher: { id: result.lastInsertRowid, name, email }
  });
});

router.delete("/teachers/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ message: "معرف غير صحيح." });

  const teacher = db.prepare("SELECT id FROM users WHERE id=? AND role='teacher'").get(id);
  if (!teacher) return res.status(404).json({ message: "المدرس غير موجود." });

  const subjectCount = db.prepare("SELECT COUNT(*) count FROM subjects WHERE teacher_id=?").get(id).count;
  if (subjectCount > 0) return res.status(409).json({ message: "لا يمكن حذف مدرس لديه مواد مرتبطة به. انقل المواد أولًا." });

  db.prepare("DELETE FROM users WHERE id=? AND role='teacher'").run(id);
  res.json({ message: "تم حذف حساب المدرس." });
});

module.exports = router;
