const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { db } = require("../database");
const { getJwtSecret, auth } = require("../middleware/auth");

router.post("/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!email || !password) return res.status(400).json({ message: "البريد الإلكتروني وكلمة المرور مطلوبان." });

  const user = db.prepare(
    "SELECT id,name,email,password,role FROM users WHERE lower(email)=?"
  ).get(email);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة." });
  }

  const token = jwt.sign(
    { id: user.id, name: user.name, email: user.email, role: user.role },
    getJwtSecret(),
    { expiresIn: "7d" }
  );

  delete user.password;
  res.json({ user, token });
});

router.get("/me", auth, (req, res) => {
  const user = db.prepare(
    "SELECT id,name,email,role,created_at FROM users WHERE id=?"
  ).get(req.user.id);
  res.json({ user });
});

module.exports = router;
