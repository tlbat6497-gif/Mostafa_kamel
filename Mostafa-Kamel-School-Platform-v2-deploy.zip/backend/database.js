const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");

const dbDir = path.join(__dirname, "..", "database");
fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.join(dbDir, "school.db"));

function initDatabase() {
  db.exec(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin','teacher','student','parent')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      grade TEXT NOT NULL,
      teacher_id INTEGER,
      FOREIGN KEY(teacher_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS lessons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      content TEXT,
      created_by INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(subject_id) REFERENCES subjects(id),
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      due_date TEXT,
      max_grade INTEGER DEFAULT 100,
      created_by INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(subject_id) REFERENCES subjects(id),
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assignment_id INTEGER NOT NULL,
      student_id INTEGER NOT NULL,
      answer TEXT,
      grade REAL,
      feedback TEXT,
      submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(assignment_id, student_id),
      FOREIGN KEY(assignment_id) REFERENCES assignments(id),
      FOREIGN KEY(student_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      created_by INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      subject_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      grade REAL NOT NULL,
      max_grade REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(student_id) REFERENCES users(id),
      FOREIGN KEY(subject_id) REFERENCES subjects(id)
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      status TEXT NOT NULL,
      FOREIGN KEY(student_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS parent_students (
      parent_id INTEGER NOT NULL,
      student_id INTEGER NOT NULL,
      PRIMARY KEY(parent_id, student_id),
      FOREIGN KEY(parent_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  seed();
}

function seed() {
  const count = db.prepare("SELECT COUNT(*) AS count FROM users").get().count;
  if (count > 0) return;

  const passwordHash = (password) => bcrypt.hashSync(password, 10);

  const insertUser = db.prepare(
    "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)"
  );

  const admin = insertUser.run(
    "مدير النظام",
    "admin@mk-school.local",
    passwordHash("Admin123!"),
    "admin"
  );

  const teacher = insertUser.run(
    "أحمد محمد",
    "teacher@mk-school.local",
    passwordHash("Teacher123!"),
    "teacher"
  );

  const student = insertUser.run(
    "أحمد علي",
    "student@mk-school.local",
    passwordHash("Student123!"),
    "student"
  );

  const parent = insertUser.run(
    "ولي أمر أحمد",
    "parent@mk-school.local",
    passwordHash("Parent123!"),
    "parent"
  );

  db.prepare("INSERT INTO parent_students(parent_id,student_id) VALUES(?,?)").run(parent.lastInsertRowid, student.lastInsertRowid);

  const subject = db.prepare(
    "INSERT INTO subjects (name,grade,teacher_id) VALUES (?,?,?)"
  ).run("الرياضيات", "الصف الثالث الإعدادي", teacher.lastInsertRowid);

  db.prepare(
    "INSERT INTO lessons (subject_id,title,description,content,created_by) VALUES (?,?,?,?,?)"
  ).run(
    subject.lastInsertRowid,
    "المعادلات الخطية",
    "مقدمة في حل المعادلات الخطية.",
    "ابدأ بعزل المتغير، ثم طبق العملية نفسها على طرفي المعادلة.",
    teacher.lastInsertRowid
  );

  const assignment = db.prepare(
    "INSERT INTO assignments (subject_id,title,description,due_date,max_grade,created_by) VALUES (?,?,?,?,?,?)"
  ).run(
    subject.lastInsertRowid,
    "واجب المعادلات",
    "حل 10 مسائل على المعادلات الخطية.",
    "2026-10-05",
    20,
    teacher.lastInsertRowid
  );

  db.prepare(
    "INSERT INTO grades (student_id,subject_id,title,grade,max_grade) VALUES (?,?,?,?,?)"
  ).run(
    student.lastInsertRowid,
    subject.lastInsertRowid,
    "اختبار قصير",
    18,
    20
  );

  db.prepare(
    "INSERT INTO announcements (title,body,created_by) VALUES (?,?,?)"
  ).run(
    "مرحبًا بكم في منصة المدرسة",
    "تم إطلاق الإصدار التجريبي من منصة مدرسة مصطفى كامل.",
    admin.lastInsertRowid
  );
}

module.exports = { db, initDatabase };
