# Mostafa Kamel School Platform v2 — Fixed

## أهم التعديلات
- لوحة Admin منفصلة.
- الـAdmin فقط يستطيع إنشاء وحذف حسابات المدرسين.
- صفحة تسجيل الدخول فيها إنشاء حساب **طلاب فقط**.
- JWT secret موجود في `.env` للتشغيل التجريبي ويجب تغييره قبل النشر.
- MK AI يعمل بدون API key في وضع Local Educational، ويمكن تفعيل Gemini 2.5 Flash-Lite المجاني بإضافة `GEMINI_API_KEY`.
- تحسين صلاحيات المدرسين والطلاب وأولياء الأمور.
- حماية من XSS وRate limiting وValidation.

## حساب المدير
- Email: `admin@mk-school.local`
- Password: `Admin123!`

## التشغيل
```bash
cd backend
npm install
npm start
```
ثم افتح `http://localhost:3000`.

> وضع الـAI المحلي لا يحتاج مفتاحًا، لكنه مساعد تعليمي بسيط وليس نموذجًا لغويًا كاملًا. للحصول على AI توليدي حقيقي، أضف `GEMINI_API_KEY` في `.env`.
